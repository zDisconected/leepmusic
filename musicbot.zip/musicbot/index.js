const Discord = require('discord.js');
const client = new Discord.Client();

const ytdl = require('ytdl-core');
const steamOptions = {
	seek: 0,
	volume: 1
};
const token = "NjA3MjM4ODI3MzU0MDk1NjY2.XkxFmA.0iw60gzs3x32UhLLQh_XvQOltA4";

client.login(token);

client.on('ready', () => {
	console.log("Logged in ass ", client.user.username + "0" + client.user.discriminator);
});

var musicUrls = [];

client.on('message', async message => {

	if(message.author.bot)
		return;

    if(message.content.toLowerCase().startsWith("?queue"))
    {
    	let args = message.content.split(" ");
    	let url = args[1];
    	let voiceChannel = message.guild.channels.find(channel => channel.id === "679421242935345170");

    	if(ytdl.validateURL(url))
    	{
    		console.log("Valid URL!");
    		var flag = musicUrls.some(element => element === url);
    		if(!flag)
    		{
    			musicUrls.push(url);
    			if(voiceChannel != null)
    			{
    				console.log("Connection exist.");
    				   const embed = new Discord.RichEmbed();
    				   embed.setAuthor(client.user.username, client.user.displayAvatarURL);
    				   embed.setDescription("You've succesfully added to the queue!");
    				   message.channel.send(embed);
    			}
    			else {
    				try {
    					const voiceConnection = await voiceChannel.join();
    					await playSong(message.channel, voiceConnection, voiceChannel);
    				}
    				catch(ex)
    				{
    					console.log(ex);
    				}
    			}
    		}
    	}
    }
});


async function playSong(messageChannel, voiceConnection, voiceChannel)
{
	const stream = ytdl(musicUrls[0], { filter : 'audioonly'});
	const dispatcher = voiceConnection.playStream(stream, steamOptions);

	dispatcher.on("end", () => {
		musicUrls.shift();

		if(musicUrls.length == 0)
			voiceChannel.leave();
		else
		{
			setTimeout(() => {
				playSong(messageChannel, voiceConnection, voiceChannel);
			}, 5000);
		}
	});
}